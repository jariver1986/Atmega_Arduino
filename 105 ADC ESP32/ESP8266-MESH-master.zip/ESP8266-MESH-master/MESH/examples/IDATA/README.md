EspMesh

Implementaci�n de la librer�a serial de software Arduino para el ESP8266
mas detalles en https://github.com/uagaviria/EspSoftwareSerial


# Esquema Esp IDATA_MESH [![i2circuit Status](https://travis-ci.org/esp8266/arduino-esp8266fs-plugin.svg?branch=master)](https://i2circuit.com)


![Screenshot](idata.png)



