                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1952198
MiniZowi by manolytyt0 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Rediseño del robot Bobwi para que las piezas encajen adecuadamente, tengan mas resistencia y se adapte a la electrónica que he selecionado.
En concreto he utilizado lo siguiente:
- un arduino nano 
- lipo de 3,7v 
- step-up a 5v
- 4 servos sg90
- mini protoboard
- cargador lipo por usb
- sensor ultrasonidos
- interruptor

https://www.youtube.com/watch?v=fz-i2mkVyGo&feature=youtu.be

La razon por la cual realizo este remix es porque me encantan los arduinos nanos, tengo un monton y me gusta hacer robots con ellos, asi que me he isto obligado a realizar un remix para adaptarlo a mi electronica y hacerlo a mi manera :)
#RemixChallenge